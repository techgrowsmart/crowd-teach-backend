// Auto-generated test cases from live requests
// Run with: npx mocha generated_tests.spec.js

const request = require('supertest');
const assert = require('assert');
const app = require('./server'); // change to your app entry point

describe('Auto Generated API Tests', function() {

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher56@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher56@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher56@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher56@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher56@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/enrollment-data/teacher should return 200', async function() {
    const res = await request(app)
      .get('/api/enrollment-data/teacher');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/enrollment-data/teacher should return 200', async function() {
    const res = await request(app)
      .get('/api/enrollment-data/teacher');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher56@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher56@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher56@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher56@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/auth/login should return 200', async function() {
    const res = await request(app)
      .post('/api/auth/login').send({"email":"teacher31@example.com","password":""});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com","source":"astraDB"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com","source":"astraDB"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/enrollment-data/teacher should return 200', async function() {
    const res = await request(app)
      .get('/api/enrollment-data/teacher');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/manresh1947%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/manresh1947%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/student1%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/student1%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/manresh1947%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/manresh1947%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/matulchaubey669%40gmail.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/matulchaubey669%40gmail.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/enrollment-data/teacher should return 200', async function() {
    const res = await request(app)
      .get('/api/enrollment-data/teacher');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/enrollment-data/teacher should return 200', async function() {
    const res = await request(app)
      .get('/api/enrollment-data/teacher');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/enrollment-data/teacher should return 200', async function() {
    const res = await request(app)
      .get('/api/enrollment-data/teacher');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('PUT /api/bookings/respond should return 200', async function() {
    const res = await request(app)
      .put('/api/bookings/respond').send({"bookingId":"booking_1776255724396_gnt7zo5wf","status":"accepted","message":"teacher31 accepted your request"});
    assert.strictEqual(res.status, 200);
  });

  it('PUT /api/bookings/respond should return 200', async function() {
    const res = await request(app)
      .put('/api/bookings/respond').send({"bookingId":"booking_1776254611835_x1e9ooibh","status":"accepted","message":"teacher31 accepted your request"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/enrollment-data/teacher should return 200', async function() {
    const res = await request(app)
      .get('/api/enrollment-data/teacher');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/auth/login should return 200', async function() {
    const res = await request(app)
      .post('/api/auth/login').send({"email":"student1@example.com","password":""});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com","source":"astraDB"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com","source":"astraDB"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/studentProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/studentProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com","source":"astraDB"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com","source":"astraDB"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/teacher31%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/teacher31%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/messages/teacher31%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/messages/teacher31%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"student1@example.com","type":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/student-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/student-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"student1@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/9845702e-bf82-43e1-9bbc-65d968cf3d81/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/8d608699-5a27-4c15-909d-76107be5ac2c/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/a7d9a917-90ac-40e0-8bf9-7c8ad3c1aea4/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/fead41fa-561d-40af-a3af-6573353eda80/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/01bff87d-b3d1-414e-aa33-4ad25ba323c0/comments');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/5ab8d992-8f67-4c62-8fe3-9cf14ee274e5/comments');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com","source":"astraDB"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com","source":"astraDB"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teachers should return 200', async function() {
    const res = await request(app)
      .post('/api/teachers').send({"count":10,"page":1});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/auth/login should return 200', async function() {
    const res = await request(app)
      .post('/api/auth/login').send({"email":"teacher31@example.com","password":""});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/posts/all should return 200', async function() {
    const res = await request(app)
      .get('/api/posts/all');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher56@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/signup should return 200', async function() {
    const res = await request(app)
      .post('/api/signup').send({"email":"teacher78working@example.com","fullName":"Sam","phonenumber":"+9107718296479","role":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/notifications/unread-count should return 200', async function() {
    const res = await request(app)
      .get('/api/notifications/unread-count');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher/enrolled-students should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher/enrolled-students');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/signup should return 200', async function() {
    const res = await request(app)
      .post('/api/signup').send({"email":"teacher78working@example.com","fullName":"Sam","phonenumber":"+9107718296479","role":"student"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/signup/verify-otp should return 200', async function() {
    const res = await request(app)
      .post('/api/signup/verify-otp').send({"email":"teacher78working@example.com","otp":"6850","name":"Sam","role":"","phone":"+9107718296479"});
    assert.strictEqual(res.status, 200);
  });
