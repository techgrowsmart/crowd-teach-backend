// Auto-generated test cases from live requests
// Run with: npx mocha generated_tests.spec.js

const request = require('supertest');
const assert = require('assert');
const app = require('./server'); // change to your app entry point

describe('Auto Generated API Tests', function() {

  it('POST /api/contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/valuesToselect should return 200', async function() {
    const res = await request(app)
      .get('/api/valuesToselect');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/allboards should return 200', async function() {
    const res = await request(app)
      .post('/api/allboards').send({"category":"Subject teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /review?email=teacher31%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/review?email=teacher31%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/bookings/teacher-requests should return 200', async function() {
    const res = await request(app)
      .get('/api/bookings/teacher-requests');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/allboards should return 200', async function() {
    const res = await request(app)
      .post('/api/allboards').send({"category":"Subject teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/teacher-subjects?email=teacher31@example.com should return 200', async function() {
    const res = await request(app)
      .get('/api/teacher-subjects?email=teacher31@example.com');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/valuesToselect should return 200', async function() {
    const res = await request(app)
      .get('/api/valuesToselect');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /review?email=teacher31%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/review?email=teacher31%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/allboards should return 200', async function() {
    const res = await request(app)
      .post('/api/allboards').send({"category":"Subject teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/firebase-contacts should return 200', async function() {
    const res = await request(app)
      .post('/api/firebase-contacts').send({"userEmail":"teacher31@example.com","type":"teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /api/valuesToselect should return 200', async function() {
    const res = await request(app)
      .get('/api/valuesToselect');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/userProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/userProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });

  it('GET /review?email=teacher31%40example.com should return 200', async function() {
    const res = await request(app)
      .get('/review?email=teacher31%40example.com');
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/allboards should return 200', async function() {
    const res = await request(app)
      .post('/api/allboards').send({"category":"Subject teacher"});
    assert.strictEqual(res.status, 200);
  });

  it('POST /api/teacherProfile should return 200', async function() {
    const res = await request(app)
      .post('/api/teacherProfile').send({"email":"teacher31@example.com"});
    assert.strictEqual(res.status, 200);
  });
